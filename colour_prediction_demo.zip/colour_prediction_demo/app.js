const COLOURS = ["Green", "Violet", "Red"];
const ROUND_SECONDS = 20;
let balance = 1000;
let roundNumber = 1001;
let secondsLeft = ROUND_SECONDS;
let selectedColour = null;
let currentPlay = null;
let history = [];

const balanceEl = document.getElementById("balance");
const roundEl = document.getElementById("round");
const timerEl = document.getElementById("timer");
const progressBar = document.getElementById("progressBar");
const stakeEl = document.getElementById("stake");
const playBtn = document.getElementById("playBtn");
const messageEl = document.getElementById("message");

document.querySelectorAll(".colour").forEach(button => {
  button.addEventListener("click", () => {
    if (currentPlay) return;
    selectedColour = button.dataset.colour;
    document.querySelectorAll(".colour").forEach(b => b.classList.toggle("selected", b === button));
    playBtn.disabled = false;
    playBtn.textContent = `Play ${selectedColour} (demo)`;
    messageEl.textContent = `${selectedColour} selected. Choose how many virtual points to use.`;
  });
});

playBtn.addEventListener("click", () => {
  if (!selectedColour || currentPlay) return;
  const stake = Number(stakeEl.value);
  if (!Number.isInteger(stake) || stake < 10 || stake > 500) {
    messageEl.textContent = "Enter between 10 and 500 virtual points.";
    return;
  }
  if (stake > balance) {
    messageEl.textContent = "Not enough virtual points. Reset the demo to start over.";
    return;
  }
  balance -= stake;
  currentPlay = { colour: selectedColour, stake, round: roundNumber };
  renderBalance();
  messageEl.textContent = `Demo pick locked: ${selectedColour} for ${stake} virtual points. Wait for the round result.`;
  playBtn.disabled = true;
  playBtn.textContent = "Round in progress";
  document.querySelectorAll(".colour").forEach(b => b.disabled = true);
});

function finishRound() {
  const result = COLOURS[Math.floor(Math.random() * COLOURS.length)];
  const played = currentPlay;
  let change = 0;
  let outcome = "No pick";
  if (played) {
    if (played.colour === result) {
      // Demo scoring only: return stake plus an equal amount of virtual points.
      change = played.stake * 2;
      balance += change;
      outcome = `Matched +${change} points`;
    } else {
      outcome = `No match −${played.stake} points`;
    }
  }
  history.unshift({ round: roundNumber, result, outcome });
  history = history.slice(0, 6);
  document.getElementById("resultDot").className = `result-dot ${result}`;
  document.getElementById("resultDot").textContent = result[0];
  document.getElementById("resultColour").textContent = result;
  document.getElementById("resultRound").textContent = `Round #${roundNumber} · ${outcome}`;
  renderHistory();
  currentPlay = null;
  selectedColour = null;
  document.querySelectorAll(".colour").forEach(b => { b.disabled = false; b.classList.remove("selected"); });
  playBtn.disabled = true;
  playBtn.textContent = "Choose a colour first";
  messageEl.textContent = "Round complete. You can choose a colour for the next demo round.";
  roundNumber += 1;
  secondsLeft = ROUND_SECONDS;
  renderBalance();
  renderRound();
}

function renderBalance() { balanceEl.textContent = balance.toLocaleString("en-IN"); }
function renderRound() {
  roundEl.textContent = `#${roundNumber}`;
  timerEl.textContent = `${secondsLeft}s`;
  progressBar.style.width = `${(secondsLeft / ROUND_SECONDS) * 100}%`;
}
function renderHistory() {
  const el = document.getElementById("history");
  if (!history.length) {
    el.innerHTML = '<p class="muted small">Results will appear here.</p>';
    return;
  }
  el.innerHTML = history.map(item => `
    <div class="history-item">
      <div class="history-left"><span class="mini-dot ${item.result}"></span><span>Round #${item.round}</span></div>
      <strong>${item.result}</strong>
    </div>`).join("");
}

document.getElementById("resetBtn").addEventListener("click", () => {
  balance = 1000; roundNumber = 1001; secondsLeft = ROUND_SECONDS;
  selectedColour = null; currentPlay = null; history = [];
  document.querySelectorAll(".colour").forEach(b => { b.disabled = false; b.classList.remove("selected"); });
  playBtn.disabled = true; playBtn.textContent = "Choose a colour first";
  messageEl.textContent = "Demo reset. Select a colour to start a demo round.";
  document.getElementById("resultDot").className = "result-dot neutral";
  document.getElementById("resultDot").textContent = "?";
  document.getElementById("resultColour").textContent = "Waiting for result";
  document.getElementById("resultRound").textContent = "Round #1000";
  renderBalance(); renderHistory(); renderRound();
});

renderBalance(); renderRound(); renderHistory();
setInterval(() => {
  secondsLeft -= 1;
  if (secondsLeft <= 0) finishRound();
  else renderRound();
}, 1000);
